"use client";
import { useState } from "react";

export default function Page() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");

  const send = async () => {
    setMessages([...messages, { from:"user", text: input }]);
    setInput("");
  };

  return (
    <div style={{ padding:40 }}>
      <h2>ARis Chat</h2>
      <div style={{ marginBottom:20 }}>
        {messages.map((m,i)=>
          <div key={i} style={{ margin:"8px 0" }}>
            <b>{m.from}:</b> {m.text}
          </div>
        )}
      </div>
      <input value={input} onChange={e=>setInput(e.target.value)} style={{ padding:8 }} />
      <button onClick={send} style={{ padding:8, marginLeft:8 }}>Enviar</button>
    </div>
  );
}
