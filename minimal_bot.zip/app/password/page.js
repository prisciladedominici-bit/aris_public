
"use client";
import { useState } from "react";

export default function PasswordPage() {
  const [pw, setPw] = useState("");
  const [error, setError] = useState(false);

  const submit = (e) => {
    e.preventDefault();
    if (pw === process.env.NEXT_PUBLIC_PASSWORD) {
      document.cookie = "auth="+pw+"; path=/";
      window.location.href="/chat";
    } else {
      setError(true);
    }
  };

  return (
    <div style={{minHeight:"100vh",display:"flex",justifyContent:"center",alignItems:"center",background:"#faf8fc"}}>
      <form onSubmit={submit} style={{background:"#fff",padding:30,borderRadius:16,boxShadow:"0 4px 14px rgba(0,0,0,0.1)"}}>
        <h2 style={{marginBottom:20}}>Ingresá la contraseña</h2>
        <input value={pw} onChange={e=>setPw(e.target.value)} type="password"
          style={{padding:10, width:"100%", marginBottom:10}}/>
        {error && <p style={{color:"red"}}>Incorrecta</p>}
        <button type="submit" style={{padding:10, width:"100%"}}>Entrar</button>
      </form>
    </div>
  );
}
