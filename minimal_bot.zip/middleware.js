import { NextResponse } from "next/server";

export function middleware(req) {
  const pw = process.env.NEXT_PUBLIC_PASSWORD;
  const has = req.cookies.get("auth")?.value === pw;

  if (req.nextUrl.pathname.startsWith("/password")) return NextResponse.next();
  if (!has) return NextResponse.redirect(new URL("/password", req.url));
  return NextResponse.next();
}

export const config = { matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"] };
