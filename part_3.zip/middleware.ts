import { NextResponse } from "next/server";

const PASSWORD = process.env.NEXT_PUBLIC_SITE_PASSWORD;

export function middleware(request: Request) {
  const url = new URL(request.url);

  const cookies = request.headers.get("cookie") || "";
  const authorized = cookies.includes(`authorized=${PASSWORD}`);

  const isAuthPage = url.pathname === "/auth";

  if (isAuthPage) {
    return NextResponse.next();
  }

  if (authorized) {
    return NextResponse.next();
  }

  url.pathname = "/auth";
  return NextResponse.redirect(url);
}

export const config = {
  matcher: "/((?!_next/static|_next/image|favicon.ico).*)",
};
